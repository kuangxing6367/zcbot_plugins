// ZCBOT 后台：内页共享逻辑（iframe 内各页共用）
// 仅负责：鉴权态 token 管理、api 封装、主题同步（与外壳读同一份 localStorage）。
(function () {
  'use strict';

  const TOKEN_KEY = 'zcbot_token';

  function getToken() { return localStorage.getItem(TOKEN_KEY) || ''; }

  async function api(path, options) {
    const opts = Object.assign({}, options, { headers: Object.assign({}, (options && options.headers) || {}) });
    const tk = getToken();
    if (tk) opts.headers['Authorization'] = 'Bearer ' + tk;
    if (opts.body && typeof opts.body === 'object' && !(opts.body instanceof FormData)) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(opts.body);
    }
    try {
      const res = await fetch(path, opts);
      let data = null;
      try { data = await res.json(); } catch (e) {}
      if (res.status === 401) {
        localStorage.removeItem(TOKEN_KEY);
        document.cookie = 'zcbot_token=; Max-Age=0; path=/';
        return { __unauth: true, code: 401 };
      }
      return data;
    } catch (e) {
      return { __neterr: true };
    }
  }

  function applyTheme() {
    let t = 'dark';
    try { const o = JSON.parse(localStorage.getItem('zc.ui') || '{}'); if (o && o.theme) t = o.theme; } catch (e) {}
    document.documentElement.setAttribute('data-theme', t);
    return t;
  }

  window.ZC = { api, getToken, applyTheme };
})();

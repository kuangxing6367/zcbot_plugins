// ZCBOT 后台：外壳 + 登录 + 侧栏逻辑（所有页面共享，按存在性守卫）
(function () {
  'use strict'

  const UI_KEY = 'zc.ui'
  const TOKEN_KEY = 'zcbot_token'

  function loadUI() { try { return JSON.parse(localStorage.getItem(UI_KEY)) || {} } catch { return {} } }
  function saveUI(patch) { try { localStorage.setItem(UI_KEY, JSON.stringify(Object.assign(loadUI(), patch))) } catch {} }

  function getToken() { return localStorage.getItem(TOKEN_KEY) || '' }
  function setToken(t) { localStorage.setItem(TOKEN_KEY, t) }
  function clearToken() {
    localStorage.removeItem(TOKEN_KEY)
    document.cookie = 'zcbot_token=; Max-Age=0; path=/'
  }

  async function api(path, options) {
    const opts = Object.assign({}, options, { headers: Object.assign({}, options && options.headers) })
    const tk = getToken()
    if (tk) opts.headers['Authorization'] = 'Bearer ' + tk
    if (opts.body && typeof opts.body === 'object' && !(opts.body instanceof FormData)) {
      opts.headers['Content-Type'] = 'application/json'
      opts.body = JSON.stringify(opts.body)
    }
    const res = await fetch(path, opts)
    let data = null
    try { data = await res.json() } catch {}
    if (res.status === 401) { clearToken(); return { __unauth: true, code: 401 } }
    return data
  }
  window.ZC = { api, getToken, setToken, clearToken }

  // —— 尽早恢复 UI（避免刷新闪跳）——
  ;(function restoreUI() {
    const ui = loadUI()
    if (ui.theme) document.documentElement.setAttribute('data-theme', ui.theme)
    const sb = document.getElementById('sidebar')
    if (sb && ui.collapsed) sb.classList.add('collapsed')
  })()

  function groupKey(el) { return el.querySelector('.gh-label, .txt') ? el.querySelector('.gh-label, .txt').textContent.trim() : '' }

  const sidebarEl = document.getElementById('sidebar')

  function syncLogo() {
    const theme = document.documentElement.getAttribute('data-theme') || 'dark'
    const collapsed = sidebarEl && sidebarEl.classList.contains('collapsed')
    const v = collapsed ? 'mini-' : ''
    const file = '/custom_ui/img/zcbot-icon-' + v + theme + '.svg'
    document.querySelectorAll('.brand img.logo').forEach(img => { img.src = file })
  }
  if (sidebarEl) syncLogo()

  function setTheme(next) {
    document.documentElement.setAttribute('data-theme', next)
    document.querySelectorAll('#themeSeg button[data-theme]').forEach(b => b.classList.toggle('on', b.dataset.theme === next))
    if (sidebarEl) syncLogo()
    saveUI({ theme: next })
  }
  window.setZCTheme = setTheme

  // 主题分段切换 + 图标按钮
  document.querySelectorAll('#themeSeg button[data-theme]').forEach(b =>
    b.addEventListener('click', () => setTheme(b.dataset.theme)))
  const themeBtn = document.getElementById('themeBtn')
  if (themeBtn) themeBtn.addEventListener('click', () => setTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'))

  // HUD 时钟
  const hudClock = document.getElementById('hudClock')
  if (hudClock) {
    const tick = () => {
      const d = new Date()
      hudClock.textContent = [d.getHours(), d.getMinutes(), d.getSeconds()].map(n => String(n).padStart(2, '0')).join(':')
    }
    tick(); setInterval(tick, 1000)
  }

  // 键盘导航
  function navItems() {
    return Array.prototype.slice.call(document.querySelectorAll('.nav a, .nav .plug-head')).filter(el => el.offsetParent !== null)
  }
  let navIdx = -1
  document.addEventListener('keydown', e => {
    if (e.target.matches('input, textarea, select')) return
    if (e.key === 't' || e.key === 'T') { setTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'); return }
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Enter') return
    const items = navItems()
    if (!items.length) return
    if (e.key === 'Enter') { if (navIdx >= 0 && navIdx < items.length) items[navIdx].click(); return }
    e.preventDefault()
    items.forEach(el => el.classList.remove('kbd-focus'))
    navIdx = (navIdx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length
    const el = items[navIdx]; el.classList.add('kbd-focus'); el.scrollIntoView({ block: 'nearest' })
  })

  // 分组 / 插件节点手风琴
  function bindAccordions(headSel, targetSel) {
    document.querySelectorAll(headSel).forEach(head => {
      head.addEventListener('click', () => {
        if (sidebarEl && sidebarEl.classList.contains('collapsed')) return
        const target = head.closest(targetSel)
        target.classList.toggle('open')
        const opens = Array.prototype.slice.call(document.querySelectorAll('.group, .plug'))
          .filter(el => el.classList.contains('open'))
          .map(el => groupKey(el))
        saveUI({ openGroups: opens })
      })
    })
  }
  if (sidebarEl) {
    bindAccordions('.group-head', '.group')
    bindAccordions('.plug-head', '.plug')
  }

  // 折叠
  const collapseBtn = document.getElementById('collapseBtn')
  if (collapseBtn && sidebarEl) {
    collapseBtn.addEventListener('click', () => {
      sidebarEl.classList.toggle('collapsed'); syncLogo(); saveUI({ collapsed: sidebarEl.classList.contains('collapsed') })
    })
  }

  // 路由进度条
  const routeBar = document.createElement('div'); routeBar.className = 'route-bar'; document.body.appendChild(routeBar)
  function barStart() { routeBar.classList.remove('done'); void routeBar.offsetWidth; routeBar.classList.add('run') }
  function barDone() { if (!routeBar.classList.contains('run')) return; routeBar.classList.add('done'); setTimeout(() => routeBar.classList.remove('run', 'done'), 450) }
  window.addEventListener('load', () => setTimeout(barDone, 120))

  // —— 外壳：侧栏点击 -> 切换主 iframe ——
  const mainFrame = document.getElementById('main')
  const titleEl = document.getElementById('pageTitle')
  const crumbEl = document.getElementById('pageCrumb')
  function navTo(href, title, crumb) {
    if (!mainFrame) return
    barStart()
    mainFrame.src = href
    if (titleEl) titleEl.textContent = title
    if (crumbEl) crumbEl.innerHTML = crumb
    document.querySelectorAll('.nav a').forEach(x => x.classList.remove('active'))
  }
  if (sidebarEl && mainFrame) {
    sidebarEl.addEventListener('click', e => {
      const sub = e.target.closest('.nav a.sub')
      const plug = e.target.closest('.plug-head')
      const item = e.target.closest('.nav a:not(.sub)')
      if (sub) {
        e.preventDefault()
        const plugin = sub.dataset.plugin, label = sub.dataset.label || sub.textContent.trim()
        document.querySelectorAll('.nav a.sub').forEach(x => x.classList.remove('active'))
        sub.classList.add('active')
        const host = sub.closest('.plug') ? sub.closest('.plug').dataset.host : ''
        const crumb = ['插件', host, label].filter(Boolean).join(' <i>/</i> ')
        navTo('/custom_ui/config.html?plugin=' + encodeURIComponent(plugin), label, crumb)
        return
      }
      if (plug) {
        e.preventDefault()
        const plugin = plug.dataset.plugin, label = plug.dataset.label || plug.textContent.trim()
        const crumb = ['插件', label].join(' <i>/</i> ')
        navTo('/api/plugin_webui/' + encodeURIComponent(plugin), label, crumb)
        return
      }
      if (item) {
        const href = item.dataset.href
        if (href) {
          e.preventDefault()
          document.querySelectorAll('.nav a:not(.sub)').forEach(x => x.classList.remove('active'))
          item.classList.add('active')
          const label = item.dataset.label || item.textContent.trim()
          const crumb = item.dataset.crumb || label
          navTo(href, label, crumb)
        }
      }
    })
    mainFrame.addEventListener('load', barDone)
  }

  // 退出登录
  const logoutBtn = document.getElementById('logoutBtn')
  if (logoutBtn) logoutBtn.addEventListener('click', async () => {
    await api('/api/logout', { method: 'POST' })
    clearToken()
    location.href = '/custom_ui/'
  })

  // —— 登录 ——
  const loginForm = document.getElementById('loginForm')
  if (loginForm) {
    const errEl = document.getElementById('loginErr')
    loginForm.addEventListener('submit', async e => {
      e.preventDefault()
      const u = document.getElementById('u').value.trim()
      const p = document.getElementById('p').value
      const btn = loginForm.querySelector('button[type=submit]')
      btn.disabled = true; if (errEl) errEl.textContent = ''
      const d = await api('/api/login', { method: 'POST', body: { username: u, password: p } })
      if (d && d.code === 0 && d.data && d.data.token) {
        setToken(d.data.token)
        location.reload()
      } else {
        btn.disabled = false
        if (errEl) errEl.textContent = (d && d.msg) || '登录失败'
      }
    })
  }

  // —— 外壳：拉取菜单（契约含 host 依赖归组）并构建侧栏插件树 ——
  const plugGroup = document.getElementById('plugGroupBody')
  if (plugGroup && getToken()) {
    ;(async function buildMenu() {
      const menu = await api('/api/menu')
      const webui = (menu && menu.data && menu.data.plugins) || []
      const byName = {}
      webui.forEach(w => { byName[w.plugin_name] = w })
      // 按 host 归组：host 指向宿主插件名；无 host 的平铺
      const html = webui.map(w => {
        const name = w.plugin_name
        const label = w.title || name
        const kids = webui.filter(c => c.host === name).map(c => {
          const cl = c.title || c.plugin_name
          return '<div class="plug" data-host="' + name + '">' +
            '<div class="plug-head" data-plugin="' + c.plugin_name + '" data-label="' + cl + '">' +
            '<svg class="ico"><use href="#i-puzzle"/></svg><span class="txt">' + cl + '</span><span class="chev sm">&rsaquo;</span></div>' +
            '<div class="plug-body"><a class="sub" data-plugin="' + c.plugin_name + '" data-label="配置">配置</a></div></div>'
        }).join('')
        const isHost = kids.length > 0
        const ico = isHost ? '#i-cpu' : '#i-puzzle'
        return '<div class="plug open" data-host="' + name + '">' +
          '<div class="plug-head" data-plugin="' + name + '" data-label="' + label + '">' +
          '<svg class="ico"><use href="' + ico + '"/></svg><span class="txt">' + label + '</span><span class="chev sm">&rsaquo;</span></div>' +
          '<div class="plug-body"><a class="sub" data-plugin="' + name + '" data-label="配置">配置</a>' + kids + '</div></div>'
      }).join('')
      plugGroup.innerHTML = html
      bindAccordions('.plug-head', '.plug')
    })()
  }
})()
